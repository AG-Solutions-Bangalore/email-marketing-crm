const BASE_URL = "https://agsdemo.online/public/api";

export default BASE_URL;
