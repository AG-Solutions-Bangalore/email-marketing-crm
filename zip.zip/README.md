Note
1. don't install MUI data table and kendo react package

